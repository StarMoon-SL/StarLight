return {
  ["Universal"] = "Universal"
}
